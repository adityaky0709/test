#!/bin/bash

sudo apt install -y npm
sudo npm install express
