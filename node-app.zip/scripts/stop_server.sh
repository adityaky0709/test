#!/bin/bash
sudo pkill node || true
